# Personal Site V17.2 — Source Code

## Build from source

```bash
# Install dependencies
npm install --legacy-peer-deps

# Generate Prisma client
npx prisma generate

# Create database
npx prisma db push

# Seed database (creates admin/admin123)
python3 scripts/seed_content.py
python3 scripts/seed_equipment.py
python3 scripts/seed_texts.py
python3 scripts/seed_access_users.py

# Generate SESSION_SECRET
echo "SESSION_SECRET=\"$(openssl rand -hex 32)\"" > .env
echo "DATABASE_URL=\"file:./db/custom.db\"" >> .env
echo "NODE_ENV=production" >> .env
echo "PORT=3000" >> .env
echo "HOSTNAME=0.0.0.0" >> .env

# Build
npx next build

# Run
cp -r .next/static .next/standalone/.next/
cp -r public .next/standalone/
cp -r db .next/standalone/
cp .env .next/standalone/
cd .next/standalone
node server.js
```

## Admin Login

- URL: http://localhost:3000/user-login
- Username: admin
- Password: admin123

## Tech Stack

- Next.js 16 (standalone build)
- TypeScript + React 19
- Prisma ORM + SQLite
- bcryptjs + crypto (HMAC-SHA256)
- Nginx (reverse proxy)
- systemd (process manager)

## Files

- src/app/ — pages + API routes
- src/components/ — React components
- src/lib/ — auth, db, utilities
- src/middleware.ts — server-side protection (CSRF + rate limit + CSP)
- prisma/schema.prisma — database schema (29 models)
- public/ — static assets
- scripts/ — seed scripts + password reset
- install.sh — production installer
